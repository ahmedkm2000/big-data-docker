package example;

import org.apache.giraph.edge.Edge;
import org.apache.giraph.graph.Vertex;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.giraph.graph.BasicComputation;

/**
 * Simple function to return the out degree for each vertex.
 */

public class InDegreeCount extends BasicComputation<LongWritable, DoubleWritable,
FloatWritable, DoubleWritable> {

  @Override
public void compute(Vertex<LongWritable, DoubleWritable, FloatWritable> vertex,
		Iterable<DoubleWritable> messages) {
	if (getSuperstep() == 0) {
		Iterable<Edge<LongWritable, FloatWritable>> edges = vertex.getEdges();
		for (Edge<LongWritable, FloatWritable> edge : edges) {
			/* Tell out-neighbors that this vertex is their in-neighbor */
			// One statement here
		}
	} else {
		double sum = 0;
		for (DoubleWritable message : messages) {
			/* Count number of messages, this implies how many in-neighbors the vertex has */
			// One statement here
		}
		DoubleWritable vertexValue = vertex.getValue();
		vertexValue.set(sum);
		vertex.setValue(vertexValue);
		vertex.voteToHalt();
	}
}

}
