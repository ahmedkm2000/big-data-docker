package example;

import java.io.IOException;

import org.apache.giraph.graph.Vertex;
import org.apache.giraph.graph.BasicComputation;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.LongWritable;

/**
	Vertex ID: LongWritable
	Vertex value: DoubleWritable
	Edge value: FloatWritable
	Message: DoubleWritable
*/

public class MaxVertexValue extends BasicComputation<LongWritable, DoubleWritable, FloatWritable, DoubleWritable> {
	
	@Override
	public void compute(Vertex<LongWritable, DoubleWritable, FloatWritable> vertex,
			Iterable<DoubleWritable> messages) throws IOException {
		boolean changed = false;
		
		for (DoubleWritable msg : messages) {
			/* Collect messages from in-neighbours and update if necessary */
			if (vertex.getValue().get() < msg.get() ) {
				vertex.setValue( new DoubleWritable( msg.get() ) );
				changed = true;
			}
		}
		
		/* Send the message to out-neighbours at Superstep 0 or Vertex value is changed */
		if (getSuperstep() == 0 || changed ) {
			sendMessageToAllEdges(vertex, vertex.getValue() );			
		}		
		vertex.voteToHalt();
	}	
}